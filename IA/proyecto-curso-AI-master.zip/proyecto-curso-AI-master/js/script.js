//Tu código va aquí. Recordad que teneis toda la documentacion en https://p5js.org/es/reference/
function setup() {
    //Este codigo se ejecuta 1 vez solamente, al principio
    createCanvas(1280, 720);
    background(220);
    //Esto es un circulo
    ellipse(100, 100, 100, 100)
}

function draw() {
    //Este codigo se ejecuta cada FRAME.
}